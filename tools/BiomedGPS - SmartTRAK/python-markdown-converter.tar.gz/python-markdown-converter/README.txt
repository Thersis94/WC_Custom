
This script was written specifically for the SmartTRAK project conversion.
It leverages the muscle of Python's Markdown APIs to do the data conversion that Java just couldn't
measure up to.

# edit the script if/as needed.
vim bin/app.py

#start the server:
python bin/app.py 

#access via the browser (use proper IP accordingly):
http://192.168.2.244:8080/

# GET request returns the form.
# POST request (parameter=content) converts the incoming data and returns it back to you.

# This was used on 03/10/2017 for the SmartTRAK UAT stand-up for over 200k records w/o issue.
# -James McKain

