
insert into wc_config (config_id, site_id, param_nm, value_txt, create_dt)
values (replace(newId(), '-', ''), 'GO_TIME_FITNESS_1', 'mindBodySiteId', '847085', getDate());

insert into wc_config (config_id, site_id, param_nm, value_txt, create_dt)
values (replace(newId(), '-', ''), 'GO_TIME_FITNESS_1', 'mindBodyApiKey', 'wvUfT2tnahYUo5+ql7Hr9FNas/o=', getDate());

insert into wc_config (config_id, site_id, param_nm, value_txt, create_dt)
values (replace(newId(), '-', ''), 'GO_TIME_FITNESS_1', 'mindBodySourceName', 'SiliconMountainTechnologies', getDate());

insert into wc_config (config_id, site_id, param_nm, value_txt, create_dt)
values (replace(newId(), '-', ''), 'GO_TIME_FITNESS_1', 'mindBodyStaffId', 'Siteowner', getDate());

insert into wc_config (config_id, site_id, param_nm, value_txt, create_dt)
values (replace(newId(), '-', ''), 'GO_TIME_FITNESS_1', 'mindBodyStaffPass', 'apitest1234', getDate());

update wc_config set value_txt = 'http://www.GoTimeFitness.com/profile' where param_nm = 'PV_TOKEN_CALLBACK_URL';
insert into wc_config (config_id, site_id, param_nm, value_txt, create_dt)
values (replace(newId(), '-', ''), 'GO_TIME_FITNESS_1', 'PV_API_KEY', 'lDn8e1j3A9ho5gXuhea9JF8enp2Wis', getDate());
insert into wc_config (config_id, site_id, param_nm, value_txt, create_dt)
values (replace(newId(), '-', ''), 'GO_TIME_FITNESS_1', 'PV_API_SECRET', 'O8b5LhMNrqdSIZj3Cwfhw1a2KvdAL6', getDate());
insert into wc_config (config_id, site_id, param_nm, value_txt, create_dt)
values (replace(newId(), '-', ''), 'GO_TIME_FITNESS_1', 'PV_TOKEN_CALLBACK_URL', 'http://a.billy.siliconmtn.com/profile', getDate());
insert into wc_config (config_id, site_id, param_nm, value_txt, create_dt)
values (replace(newId(), '-', ''), 'GO_TIME_FITNESS_1', 'PV_TOKEN_SERVER_URL', 'https://www.perkville.com/api/token/', getDate());
insert into wc_config (config_id, site_id, param_nm, value_txt, create_dt)
values (replace(newId(), '-', ''), 'GO_TIME_FITNESS_1', 'PV_AUTH_SERVER_URL', 'https://www.perkville.com/api/authorize/', getDate());
insert into wc_config (config_id, site_id, param_nm, value_txt, create_dt)
values (replace(newId(), '-', ''), 'GO_TIME_FITNESS_1', 'PV_SCOPE', 'PUBLIC,USER_CUSTOMER_INFO', getDate());
insert into wc_config (config_id, site_id, param_nm, value_txt, create_dt)
values (replace(newId(), '-', ''), 'GO_TIME_FITNESS_1', 'PV_AUTH_CODE_RESPONSE', 'code', getDate());
insert into wc_config (config_id, site_id, param_nm, value_txt, create_dt)
values (replace(newId(), '-', ''), 'GO_TIME_FITNESS_1', 'PV_GRANT_TYPE_CODE', 'authorization_code', getDate());