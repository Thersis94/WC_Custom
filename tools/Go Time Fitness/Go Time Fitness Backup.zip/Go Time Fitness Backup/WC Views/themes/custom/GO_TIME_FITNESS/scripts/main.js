var GTF = {
		MB_AMID: 'mindBody',
		SITE: {
			init: function() {
				GTF.SITE.bindMobileLink();
			},
			bindMobileLink: function() {
				$('.gtf-header-hamburger').on('click', function(e) {
				    e.preventDefault();
				
				    var $this = $(this),
				      $target = $($this.attr('href'));
				
				    $target.fadeToggle({
						duration: 200,
						complete: function() {
							if(!$target.hasClass("show-menu")) {
								$target.addClass("show-menu");
							} else {
								$target.removeClass("show-menu");
							}
							$target.removeAttr('style');
						}
					});
			  });
			}
		},
		HOME: {
			bindMainSlider: function() {
				$('.gtf-slider_main .js-slider').each(function () {
				    var sliderMain = new Swiper($(this), {
				        autoplay: true,
				        pagination: {
				          el: $(this).parent().find('.swiper-pagination'),
				          clickable: true
				        }
				      });
				});
			},
			bindSliders: function() {
				$('.gtf-slider_4items .js-slider').each(function () {
				    var sliderTrainers = new Swiper($(this), {
				        slidesPerView: 4,
				        spaceBetween: 30,
				        pagination: {
				          el: $(this).parent().find('.swiper-pagination'),
				          clickable: true
				        }
				      });

				    $(window).on('resize', function () {
				      var windW = $(window).width();

				      if (windW >= 992) sliderTrainers.params.slidesPerView = 4;
				      if (windW > 567 && windW < 992) sliderTrainers.params.slidesPerView = 2;
				      if (windW < 567) sliderTrainers.params.slidesPerView = 1;

				      sliderTrainers.update();
				    });

				    $(window).trigger('resize');
				});
			},
			bindEnjoyableClasses: function() {
				 $('.gtf-nav-tabs_desktop__link, .gtf-nav-tabs_mobile__link').on('click', function(e) {
				      e.preventDefault();
	
				      var $this = $(this),
				        target = $this.attr('href');
				      console.log(target);
				      $('.gtf-nav-tabs_desktop__link, .gtf-nav-tabs_mobile__link').removeClass('active');
	
				      $this.addClass('active');
	
				      $('.gtf-tabs__item').removeClass('active').hide();
	
				      $(target).fadeIn(400, function() {
				        $(target).addClass('active')
				      });
				 });
			}
		},
		USER: {
			init: function() {
				$("#purchaseHistoryTable").bootstrapTable(GTF.USER.purchaseHistoryTableConfig());
			},
			purchaseHistoryTableConfig: function() {
				return {
					queryParams: function(params) {
						params.json = true;
						params.amid = GTF.MB_AMID;
						params.isBootstrapTable = true;
						params.loadData = true;
						params.view = true;
						params.actionType = "client";
						params.callType = "GET_CLIENT_PURCHASES";
						params.reqType = "retrieve";
						return params;
					},
					sortName : 'purchaseDt',
					sortOrder : 'desc',
					columns: [{
						title: 'Description',
						field: 'description'
					},{
						title: "Quantity",
						field: "quantity",
					}, {
						title: "Price",
						field: "price",
					}, {
						title: 'Purchase Date',
						field: 'purchaseDt',
						sortName : 'purchaseSortDt',
						sortable: true
					}, {
						title: 'Total',
						field: 'total',
					}]
				};
			}
		},
		UTIL: {
			bsTableResponseHandler : function (res) {
				if(res.isSuccess) {

					/*
					 * If call was a success and data was returned, return the data.
					 * Else return an empty array to the table framework.
					 */
					if(res.jsonActionError != "no data" && res.actionData !== null) {
						return res.actionData;
					} else {
						return [];
					}
				}
			},
			getDataViaAjax: function (reqData, params, overrideMethod) {
				var method = isEmpty(overrideMethod)? "GET" : overrideMethod;

				$.ajax({
					method: method,
					url : "/json",
					data : params,
					traditional : true,
					success: function(data) {
						reqData.responseText = data;
			        	reqData.callBack(reqData);
		            }
				});
			}
		}
}